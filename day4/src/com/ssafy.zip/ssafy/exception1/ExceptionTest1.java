package com.ssafy.exception1;

public class ExceptionTest1 {
	public static void main(String[] args) {
		int[] nums = { 10 };
		
		//Unchecked Exception
		System.out.println(nums[2]);
		
		//Checked Excpetion
//		Thread.sleep(1000);
		
		
		System.out.println("프로그램을 종료합니다.");
	}
}
