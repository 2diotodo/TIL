package com.ssafy.collection;

import java.util.Arrays;

public class SortTest3 {
	public static void main(String[] args) {
		
		int[] nums = {20,25,23,33,32,39};
		
		Arrays.sort(nums);
		
		System.out.println(Arrays.toString(nums));
	}
}
