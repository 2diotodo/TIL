package com.ssafy.collection;

import java.util.Collection;

public class CollectionTest {
	public static void main(String[] args) {
//		Collection<E>;
	}
}
