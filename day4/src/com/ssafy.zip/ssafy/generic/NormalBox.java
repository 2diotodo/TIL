package com.ssafy.generic;

public class NormalBox {
	private Object some;

	public Object getSome() {
		return some;
	}

	public void setSome(Object some) {
		this.some = some;
	}
	
}
