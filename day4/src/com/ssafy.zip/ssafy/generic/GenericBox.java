package com.ssafy.generic;

public class GenericBox<T> {
	private T some;

	public T getSome() {
		return some;
	}

	public void setSome(T some) {
		this.some = some;
	}

}
