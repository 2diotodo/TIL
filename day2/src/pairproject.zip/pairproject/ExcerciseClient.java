package pairproject;

public class ExcerciseClient {

	//운동 리스트 출력
	
	
	//운통 검색
}
