package com.ssafy.class02;


// 이러한 다양한 자료형 가질수 있는 자료형을 만들고 싶다.
public class Person {
	String name;
	int age;
	String hobby;
}
